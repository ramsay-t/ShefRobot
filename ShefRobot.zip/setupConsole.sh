#!/bin/bash
# setupConsole.sh
export CLASSPATH=.:bluecove-2.1.0.jar:ShefRobot.jar:dbusjava.jar:ev3classes.jar:$classpath